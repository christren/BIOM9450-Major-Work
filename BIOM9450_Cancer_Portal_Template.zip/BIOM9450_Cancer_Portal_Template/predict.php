<?php
$pageTitle = 'Cancer Prediction';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Cancer Type Prediction</h2>
    <p>This page will send selected mutation data to the machine learning model.</p>
    <p>Prediction results and class probabilities will eventually appear here.</p>
    <form class="demo-form" data-demo-form>
        <label for="sample-id">Sample ID</label>
        <input type="text" id="sample-id" placeholder="Enter a sample ID">
        <button type="submit">Predict (placeholder only)</button>
        <p class="form-message" aria-live="polite"></p>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
