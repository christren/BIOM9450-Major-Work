    </main>
    <footer class="site-footer">
        <div class="container"><p>BIOM9450 — Website template only</p></div>
    </footer>
    <script src="assets/js/script.js"></script>
</body>
</html>
