<?php
// Shared header: included by each PHP page so navigation stays consistent.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$pageTitle = $pageTitle ?? 'Cancer Research Portal';
$currentPage = basename($_SERVER['PHP_SELF']);
$demoRole = $_SESSION['demo_role'] ?? 'Guest';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?> | Cancer Research Portal</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <h1>Cancer Research Portal</h1>
            <p>BIOM9450 Major Project — Basic website layout</p>
        </div>
    </header>
    <nav class="site-nav" aria-label="Main navigation">
        <div class="container nav-links">
            <a href="index.html">Home</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="patients.php">Patients</a>
            <a href="mutations.php">Mutations</a>
            <a href="add_patient.php">Add Patient</a>
            <a href="upload_mutations.php">Upload Mutations</a>
            <a href="predict.php">Prediction</a>
            <a href="visualisations.php">Visualisations</a>
            <a href="feedback.php">Feedback</a>
            <a href="logout.php">Log Out</a>
        </div>
    </nav>
    <main class="container">
        <p class="demo-note">Demo template — viewing pages does not require authentication. Selected role: <?= htmlspecialchars($demoRole, ENT_QUOTES, 'UTF-8') ?>.</p>
