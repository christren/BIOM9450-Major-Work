<?php
$pageTitle = 'Prediction Feedback';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Prediction Feedback</h2>
    <p>This page will allow users to comment on cancer predictions and whether they were accurate.</p>
    <p>Feedback will eventually be linked to a prediction record in MySQL.</p>
    <form class="demo-form" data-demo-form>
        <label for="feedback-text">Feedback</label>
        <textarea id="feedback-text" rows="4" placeholder="Enter feedback"></textarea>
        <button type="submit">Submit (placeholder only)</button>
        <p class="form-message" aria-live="polite"></p>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
