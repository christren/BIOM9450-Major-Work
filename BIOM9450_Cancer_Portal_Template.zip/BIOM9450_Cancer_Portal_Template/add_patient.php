<?php
$pageTitle = 'Add Patient';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Add Patient</h2>
    <p>This page will contain a form for oncologists or researchers to add a patient record.</p>
    <form class="demo-form" data-demo-form>
        <label for="patient-id">Patient ID</label>
        <input type="text" id="patient-id" placeholder="Enter a patient ID">
        <label for="cancer-type">Cancer type</label>
        <select id="cancer-type">
            <option value="">Select a cancer type</option>
            <option>BRCA</option><option>LAML</option><option>LGG</option>
            <option>LIHC</option><option>PAAD</option><option>PRAD</option>
        </select>
        <button type="submit">Save (placeholder only)</button>
        <p class="form-message" aria-live="polite"></p>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
