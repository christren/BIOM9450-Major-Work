<?php
$pageTitle = 'Browse Mutations';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Browse Mutations</h2>
    <p>This page will list genetic mutation records from the database.</p>
    <p>Later we will add filters for chromosome, gene, mutation type and genomic position.</p>
    <form class="demo-form" data-demo-form>
        <label for="gene">Gene name</label>
        <input type="text" id="gene" placeholder="Example: TP53">
        <button type="submit">Search (placeholder only)</button>
        <p class="form-message" aria-live="polite"></p>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
