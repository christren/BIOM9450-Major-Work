<?php
$pageTitle = 'Patient Details';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Patient Details</h2>
    <p>This page will display one patient's details, cancer type and linked samples.</p>
    <p>We will eventually list mutations associated with that patient's tumour samples.</p>
    <a href="patients.php">Back to patient list</a>
</section>
<?php include 'includes/footer.php'; ?>
