<?php
$pageTitle = 'Visualisations';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Mutation Visualisations</h2>
    <p>This page will show graphs of mutations by gene and cancer type.</p>
    <p>Researchers will eventually be able to select genes and explore the results in interactive charts.</p>
    <div class="chart-placeholder">Chart area (to be added later)</div>
</section>
<?php include 'includes/footer.php'; ?>
