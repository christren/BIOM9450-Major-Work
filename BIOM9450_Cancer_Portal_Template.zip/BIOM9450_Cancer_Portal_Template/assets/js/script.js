// Small amount of JavaScript for the template.
// For now, forms only display a message; no data is saved or uploaded.

document.querySelectorAll('[data-demo-form]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        var message = form.querySelector('.form-message');
        if (message) {
            message.textContent = 'Template only — this feature is not connected yet.';
        }
    });
});
