<?php
// Simple role selector for previewing layouts only. THIS IS NOT REAL AUTHENTICATION.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $allowedRoles = ['Oncologist', 'Researcher', 'Patient'];
    $role = $_POST['role'] ?? '';
    if (in_array($role, $allowedRoles, true)) {
        $_SESSION['demo_role'] = $role;
        header('Location: dashboard.php');
        exit;
    }
}
$pageTitle = 'Login';
include 'includes/header.php';
?>
<section class="panel narrow">
    <h2>Login</h2>
    <p>This page will eventually check a username and password against the database.</p>
    <p>For now, choose a demo role to preview the dashboard layout.</p>
    <form method="post">
        <label for="role">Preview as</label>
        <select name="role" id="role" required>
            <option value="">Choose a role</option>
            <option value="Oncologist">Oncologist</option>
            <option value="Researcher">Researcher</option>
            <option value="Patient">Patient</option>
        </select>
        <button type="submit">Continue to dashboard</button>
    </form>
    <p class="small-text">No username or password is checked. Replace this preview screen with a secure login system later.</p>
</section>
<?php include 'includes/footer.php'; ?>
