<?php
$pageTitle = 'Upload Mutations';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Upload Mutations</h2>
    <p>This page will allow users to upload tab-delimited mutation files for a patient or sample.</p>
    <p>File validation and MySQL insertion will be added later.</p>
    <form class="demo-form" data-demo-form>
        <label for="mutation-file">Choose a text file</label>
        <input type="file" id="mutation-file" accept=".txt,.tsv">
        <button type="submit">Upload (placeholder only)</button>
        <p class="form-message" aria-live="polite"></p>
    </form>
</section>
<?php include 'includes/footer.php'; ?>
