<?php
$pageTitle = 'Dashboard';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Dashboard</h2>
    <p>This page will be the main dashboard after login.</p>
    <p>We will eventually show summary information and links suited to each user role.</p>
</section>
<section class="card-grid">
    <article class="panel"><h3>Patient Records</h3><p>Overview of patients in the database.</p><a href="patients.php">View patients</a></article>
    <article class="panel"><h3>Mutation Data</h3><p>Overview of genetic mutation records.</p><a href="mutations.php">View mutations</a></article>
    <article class="panel"><h3>Cancer Prediction</h3><p>Placeholder for the machine learning feature.</p><a href="predict.php">Open prediction page</a></article>
</section>
<?php include 'includes/footer.php'; ?>
