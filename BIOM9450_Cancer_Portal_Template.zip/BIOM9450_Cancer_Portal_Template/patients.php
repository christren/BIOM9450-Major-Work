<?php
$pageTitle = 'Patient List';
include 'includes/header.php';
?>
<section class="panel">
    <h2>Patient List</h2>
    <p>This page will show patients stored in the MySQL database.</p>
    <p>Later, users will be able to search for patients and open their profiles.</p>
    <a class="button" href="patient_details.php">Preview patient details</a>
</section>
<?php include 'includes/footer.php'; ?>
